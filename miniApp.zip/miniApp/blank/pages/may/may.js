Page({
  data: {
     navArr:[{
      path:'/pages/other/other',
      name:'我的订单',
      icon:'../../images/icon/1.png'
    },{
      path:'/pages/coupon/coupon',
      name:'我的优惠卷',
      icon:'../../images/icon/2.png'
    },{
      path:'/pages/invite/invite',
      name:'邀请好友',
      icon:'../../images/icon/3.png'
    },{
      path:'/pages/helpCenter/helpCenter',
      name:'帮助中心',
      icon:'../../images/icon/4.png'
    }],
  },
  onLoad() {},
});
