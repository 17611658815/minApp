Page({
  data: {
    wuliu: ['已接收', '抵达深圳', '抵达广州'],
  },
  onLoad() {},
});
