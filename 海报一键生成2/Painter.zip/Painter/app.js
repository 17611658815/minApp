
App({
  onLaunch: function () {
  },

  globalData: {
    //   https://github.com/Kujiale-Mobile/Painter
    systemInfo: {
      ...wx.getSystemInfoSync(),
    },
  },

});

