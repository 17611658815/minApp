var app = getApp();
export default class LastMayday {
    palette() {
        return ({
            width: '654rpx',
            height: '1000rpx',
            background: '#f8f8f8',

            views: [{
                    type: 'image',
                    url: '/palette/images/img.jpg',
                    css: {
                        width: '654rpx',
                        height: '1000rpx',
                    },
                },
                {  //二维码图片
                    type: 'image',
                    url: '/palette/images/code.png',
                    css: {
                        right: '40rpx',
                        bottom: '40rpx',
                        width: '200rpx',
                        height: '200rpx',
                        borderRadius: '20px',
                    },
                },
                {  //头像
                    type: 'image',
                    url: '/palette/images/b8bf338a2419235ac987f720745d46a.jpg',
                    css: {
                        right: '227rpx',
                        top: '40rpx',
                        width: '200rpx',
                        height: '200rpx',
                        borderRadius: '100px',
                    },
                },
                // _textDecoration('overline', 0),
                // _textDecoration('underline', 1),
                // _textDecoration('line-through', 2),
                // _textDecoration('overline underline line-through', 3, 'red'),
                // {
                //   type: 'rect',
                //   css: {
                //     width: '200rpx',
                //     right: '20rpx',
                //     top: '30rpx',
                //     height: '100rpx',
                //     shadow: '10rpx 10rpx 5rpx #888888',
                //     color: 'linear-gradient(-135deg, #fedcba 0%, rgba(18, 52, 86, 1) 20%, #987 80%)',
                //   },
                // },
                // {
                //   id: 'my-text-id',
                //   type: 'text',
                //   text: "fontWeight: 'bold'",
                //   css: [{
                //     top: `${startTop + 4 * gapSize}rpx`,
                //     shadow: '10rpx 10rpx 5rpx #888888',
                //     fontWeight: 'bold',
                //   }, common],
                // },
                // {
                //   type: 'rect',
                //   css: {
                //     width: '20rpx',
                //     height: '20rpx',
                //     color: 'red',
                //     left: [`${startTop}rpx`, 'my-text-id'],
                //     top: `${startTop + 4 * gapSize + 15}rpx`,
                //   },
                // },
                {  //文字
                    type: 'text',
                    text: '追随热情，忠于自我，绝不要追随别人的脚步',
                    css: [{
                        top: `${startTop + 5 * gapSize}rpx`,
                        width: '400rpx',
                        fontSize: "30rpx",
                        align:'center',
                        // background: '#538e60',
                        color: '#538e60',
                        fontWeight: "bold",
                        lineHeight:'50rpx'
                    }, common, {
                        left: '340rpx',
                        top: '250rpx'
                    }],
                },
                {  //文字
                    type: 'text',
                    text: '追随热情，忠于自我，绝不要追随别人的脚步',
                    css: [{
                        top: `${startTop + 5 * gapSize}rpx`,
                        width: '400rpx',
                        fontSize: "35rpx",
                        color: '#fff',
                        fontWeight: "normal",
                        lineHeight:'50rpx'
                    }, common, {
                        left: '20rpx',
                        top: '800rpx'
                    }],
                },
                // _image(0),
                // _des(0, '普通'),
                // _image(1, 30),
                // _des(1, 'rotate: 30'),
                // _image(2, 30, '20rpx'),
                // _des(2, 'borderRadius: 30rpx'),
                // _image(3, 0, '100rpx'),
                // _des(1, '圆形'),
                // {
                //   type: 'image',
                //   url: '/palette/avatar.jpg',
                //   css: {
                //     bottom: '40rpx',
                //     left: '40rpx',
                //     borderRadius: '50rpx',
                //     borderWidth: '10rpx',
                //     borderColor: 'yellow',
                //     width: '100rpx',
                //     height: '100rpx',
                //   },
                // },
                // {
                //   type: 'qrcode',
                //   content: 'https://github.com/Kujiale-Mobile/Painter',
                //   css: {
                //     bottom: '40rpx',
                //     left: '180rpx',
                //     color: 'red',
                //     borderWidth: '10rpx',
                //     borderColor: 'blue',
                //     width: '120rpx',
                //     height: '120rpx',
                //   },
                // },
                // {
                //   type: 'rect',
                //   css: {
                //     bottom: '40rpx',
                //     right: '40rpx',
                //     color: 'radial-gradient(rgba(0, 0, 0, 0) 5%, #0ff 15%, #f0f 60%)',
                //     borderRadius: '20rpx',
                //     borderWidth: '10rpx',
                //     width: '120rpx',
                //     height: '120rpx',
                //   },
                // },
                // {
                //   type: 'text',
                //   text: 'borderWidth',
                //   css: {
                //     bottom: '40rpx',
                //     right: '200rpx',
                //     color: 'green',
                //     borderWidth: '2rpx',
                //   },
                // },
            ],
        });
    }
}

const startTop = 50;
const startLeft = 20;
const gapSize = 70;
const common = {
    left: `${startLeft}rpx`,
    // fontSize: '40rpx',
};

function _textDecoration(decoration, index, color) {
    return ({
        type: 'text',
        text: decoration,
        css: [{
            top: `${startTop + index * gapSize}rpx`,
            color: color,
            textDecoration: decoration,
        }, common],
    });
}

function _image(index, rotate, borderRadius) {
    return ({
        type: 'image',
        url: '/palette/images/code.png',
        css: {
            top: `${startTop + 8.5 * gapSize}rpx`,
            left: `${startLeft + 90 * index}rpx`,
            width: '200rpx',
            height: '200rpx',
            shadow: '10rpx 10rpx 5rpx #888888',
            rotate: rotate,
            borderRadius: borderRadius,
        },
    });
}

function _des(index, content) {
    const des = {
        type: 'text',
        text: content,
        css: {
            fontSize: '22rpx',
            top: `${startTop + 8.5 * gapSize + 140}rpx`,
        },
    };
    if (index === 3) {
        des.css.right = '60rpx';
    } else {
        des.css.left = `${startLeft + 120 * index + 30}rpx`;
    }
    return des;
}