const app = getApp();
Page({
  data: {
    ColorList: app.globalData.ColorList
  }
})
